function [AL, t] = ArcLengthParam(boundary)
%AL: boundary���ܻ���
%t: ��������
N = length(boundary);
t = zeros(N,1);
t(1) = 0;
bx = boundary(:,1);
%bx = bx(1:length(bx) -1);
by = boundary(:,2);
%by = by(1:length(by) -1);
t(2:N) = sqrt(diff(bx).^2+diff(by).^2);
AL = sum(t);
t = cumsum(t);