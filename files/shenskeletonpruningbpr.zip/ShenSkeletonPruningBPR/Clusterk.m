function [cx, cy, cn, nce] = Clusterk(nbx, nby, x, y, boundary, Bsh, ts, ALS, T)

bx = nbx(1);
by = nby(1);

for i = 2:length(nbx)
    beIn = 0;
    for j =1:length(bx)
        if(all([nbx(i), nby(i)] == [bx(j), by(j)]))
            beIn = 1;
            break;
        end
    end
    if(~beIn)
        bx = [bx, nbx(i)];
        by = [by, nby(i)];
    end
end
cx = [];
cy = [];
nce = [];
cx(1,1) = bx(1);
cy(1,1) = by(1);
cn = 1;
nce(1) = 1;
if(length(bx) == 1)
    return;
end
rm = [];
bi = [];
bbi = [];
for i = 1:length(bx)
    ti = find(boundary(:,1) == bx(i) & boundary(:,2) == by(i));
    k = 1;
    while(isempty(ti))
        contour = Bsh{k};
        ti = find(contour(:,1) == bx(i) & contour(:,2) == by(i));
        k = k+1;
    end
    ti = ti(1);
    bi = [bi, ti];
    bbi = [bbi, k];
    rm = [rm, sqrt((bx(i) - x) .^2 + (by(i) - y) .^2)];
end
tm = [];
for i = 1:length(bi)
    for j = 1:length(bi)
        if(bbi(i) == bbi(j))
            t = ts{bbi(i)};
            AL = ALS(bbi(i));
            tm(i,j) = min(abs(t(bi(i)) - t(bi(j))), AL - abs(t(bi(i)) - t(bi(j))));
        else
            tm(i,j) = Inf;
        end
    end
end
[tmax,mi] = max(tm(1,:));
dbp = sqrt((bx(mi) - bx(1)) .^2 + (by(mi) - by(1)) .^2);
theta = acos((rm(1) .^2 + rm(mi) .^2 - dbp .^2) / 2 / rm(1) / rm(mi));
er = sqrt(tmax .^2 - dbp .^2) * dbp / rm(1) / rm (mi) / 2 / sin(theta);
if(er >= T)
    cn = 2;
    cx(2,1) = bx(mi);
    cy(2,1) = by(mi);
    nce(2) = 1;
else
    nce(1) = 2;
    cx(1,2) = bx(mi);
    cy(1,2) = by(mi);
end

for i = 1:length(bx)
    createnew = 1;
    for j = 1:cn
        bi = i;
        ci = find(bx == cx(j,1) & by == cy(j,1));
        if(bi == ci)
            createnew = 0;
            continue;
        end
        dbp = sqrt((bx(i) - cx(j,1)) .^2 + (by(i) - cy(j,1)) .^2);
        theta = acos((rm(bi) .^2 + rm(ci) .^2 - dbp .^2) / 2 / rm(bi) / rm(ci));
        er = sqrt(tm(bi,ci) .^2 - dbp .^2) * dbp / rm(bi) / rm (ci) / 2 / sin(theta);
        if er < T
            createnew = 0;
            nce(j) = nce(j) + 1;
            cx(j, nce(j)) = bx(i);
            cy(j, nce(j)) = by(i);
            break;
        end
    end
    if(createnew)
        cn = cn + 1;
        cx(cn,1) = bx(i);
        cy(cn,1) = by(i);
        nce(cn) = 1;
    end
end