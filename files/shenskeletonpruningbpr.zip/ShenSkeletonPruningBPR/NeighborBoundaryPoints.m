function [nbx,nby] = NeighborBoundaryPoints(x,y,dist,lab)

[m,n] = size(lab);
nbx = [];
nby = [];
[by,bx] = Lab2Pos(lab(x,y),m,n);
nbx = bx;
nby = by;
k = 2;
for i = max(x-1,1):min(x+1,m)
    for j = max(y-1,1):min(y+1,n)
        if(any([i,j] ~= [x,y]) & dist(i,j) > 0)
            [by,bx] = Lab2Pos(lab(i,j),m,n);
            nbx(k) = bx;
            nby(k) = by;
            k = k + 1;
        end
    end
end