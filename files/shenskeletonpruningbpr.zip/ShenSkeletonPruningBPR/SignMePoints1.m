function [cx,cy,cn, nce] = SignMePoints1(dist,lab,x,y,boundary,Bsh,ts,ALS,epsilon)

[m,n]=size(dist);
[nbx,nby] = NeighborBoundaryPoints(x, y, dist, lab);
[cx, cy, cn, nce] = Clusterk(nbx, nby, x, y, boundary,Bsh, ts, ALS,epsilon);