function skltn = SkeletonGrow1(bw,boundary,Bsh,ro,epsilon)
%---------------------------------------

%--------------------------------------
[m,n] = size(bw);
skltn = zeros(m,n);

[dist,lab] = bwdist(bw);
dist = double(dist);
lab = double(lab);
% the star point of the skeleton
root = find(dist == max(max(dist))); 
root = root(1);

%accsee matrix
bAccess = zeros(m,n);

curPoint = [0,0];
[curPoint(2),curPoint(1)] = Lab2Pos(root,m,n);

skltn(curPoint(1),curPoint(2)) = dist(curPoint(1),curPoint(2));
bAccess(curPoint(1),curPoint(2)) = 1;

%access stack
AccessStack = [curPoint];

bn = length(Bsh) + 1;
ALS = [];
ts = cell(bn,1);
[AL, t] = ArcLengthParam(boundary);
ALS = [ALS;AL];
ts{1} = t;
for i = 1:length(Bsh)
    bh = Bsh{i};
    [AL, t] = ArcLengthParam(bh);
    ALS = [ALS;AL];
    ts{i+1} = t;
end
% from the start point, check the 4-adjent points and the 8-adjent points
nAdj = 0;
while (length(AccessStack) ~= 0);
    nAdj = nAdj + 1;

    curPoint = AccessStack(1,:);
    
    [tm,tn] = size(AccessStack);
    AccessStack = AccessStack(2:tm,:);
    for i = max(curPoint(1)-1,1):min(curPoint(1)+1,m);
        for j = max(curPoint(2)-1,1):min(curPoint(2)+1,n);
            if bAccess(i,j) == 0 & bw(i,j) == 0;
                skltn(i,j) = checkskeleton1(bw,dist,lab,i,j,boundary,Bsh, ts,ALS,ro,epsilon);
                if skltn(i,j) ~= 0;
                        bAccess(i,j) = 1;
                        AccessStack = [[i,j];AccessStack];
                else
                    bAccess(i,j) = -1;
                end;
            end;
        end;
    end;
end;
     
