clc;
clear;


epsilon = 0.8;
sf = 'horse079.jpg';
I = imread(sf);

skel = skel_pruning_bpr(I, epsilon, 9);


imshow(~im2bw(I)+skel);

imwrite(~im2bw(I)+skel, 'horse079(0.8).png');
   