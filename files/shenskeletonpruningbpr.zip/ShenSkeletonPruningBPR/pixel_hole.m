function g = pixel_hole(f)

persistent lut

if isempty(lut)
   lut = makelut(@pixel_hole_fcn, 3);
end

g = applylut(f,lut);

%-------------------------------------------------------------------%
function is_pixel_hole = pixel_hole_fcn(nhood)

is_pixel_hole = ~nhood(2,2) & nhood(1,2) & nhood(2,1) & nhood(3,2) & nhood(2,3);