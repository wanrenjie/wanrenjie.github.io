function skel = skel_pruning_bpr(I, bpr_th, chord_th)

if nargin < 2
    bpr_th = 0.8;    
end
if nargin < 3
    chord_th = 9;
end
bw = im2bw(I);
bw = bwmorph(bw, 'clean');
g = pixel_hole(bw);
bw = bw | g;

bw1 = bw;

bw= 1-bw; %the shape must be black, i.e., values zero.
bwe = bwperim(bw1);
bw2 = bw1 - bwe;
bw0 = 1 - bw2;

Bs = bwboundaries(bw1);

boundary = Bs{1};
for i = 1:length(boundary(:,1))
    bwe(boundary(i,1), boundary(i,2)) = 0;
end

Bsh = bwboundaries(bwe, 'noholes');
% tic;
SK=SkeletonGrow1(bw0,boundary,Bsh,chord_th,bpr_th);
skel = bwmorph(SK, 'thin') .* SK;