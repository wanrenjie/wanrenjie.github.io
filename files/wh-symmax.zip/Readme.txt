This dataset, WH-SYMMAX, which is converted from the well known Weizmann Horse dataset [1], is used for evaluating the methods for skeleton extraction in natural images. The groundtruth skeleton map of each image is obtained by applying skeletonization [2] on provided human-annotated foreground segments. We have split the training and testing sets. Each groundtruth is represented by a .mat file, in which there are three fields:

ct: the contour map of the object. 1: contour; 0: non-contour.
segmentation: the segmentation map of the object. 1: foreground; 0: background.
sym: the skeleton map of the object. >0: skeleton, and the value is the radius of the maximal disc centered at each skeleton pixel; 0: non-skeleton.


If you use this dataset, please cite our paper:

@article{Ref:Shen15,
  author    = {Wei Shen and Xiang Bai and Zihao Hu and Zhijiang Zhang},
  title     = {Multiple instance subspace learning via partial random projection tree for local reflection symmetry in natural images},
  journal   = {Pattern Recognition},
  year      = {2015},
}

For any questions about this dataset, please contact me by email: wei.shen@t.shu.edu.cn


[1] E. Borenstein, S. Ullman, Class-specific, top-down segmentation, in: Proc. ECCV, 2002, p. 109-124. 
[2] W. Shen, X. Bai, R. Hu, H. Wang, L.J. Latecki, Skeleton growing and pruning with bending potential ratio, Pattern Recognition 44 (2011) 196�C209.